#define DBGMSG_L2                       0 //debug print control
#define DBGMSG_L3                       0 //debug print control

#define L3_MAXDATASIZE                  1024


#define L2_ARQ_MAXRETRANSMISSION        3
#define L2_ARQ_MAXWAITTIME              5
#define L2_ARQ_MINWAITTIME              2