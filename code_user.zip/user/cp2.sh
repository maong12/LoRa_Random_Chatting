#!/bin/sh



cp ./BUILD/myProtocol.bin /Volumes/NODE_F446RE\ 1
