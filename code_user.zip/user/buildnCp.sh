#!/bin/sh

make clean
make
cp ./BUILD/myProtocol.bin /Volumes/NODE_F446RE
