void L2_timer_startTimer();
void L2_timer_stopTimer();
uint8_t L2_timer_getTimerStatus();