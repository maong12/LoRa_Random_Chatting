#include "mbed.h"
int L3_msg_isEndChat(char * originalWord);

