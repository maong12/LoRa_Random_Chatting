void L2_initFSM(uint8_t myId);
void L2_FSMrun(void);