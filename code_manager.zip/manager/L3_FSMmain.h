#include <stdint.h>
void L3_initFSM();
void L3_FSMrun(void);
int MATCHING(int size);
void cleanMATCH(int num);
void printArr(int len);
void printArr2(int len);
int checkMatchCdtion();
