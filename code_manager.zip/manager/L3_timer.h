void L3_timer_startTimer();
void L3_timer_stopTimer();
uint8_t L3_timer_getTimerStatus();