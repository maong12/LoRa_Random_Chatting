#include "L3_FSMmain.h"
#include "L3_FSMevent.h"
#include "L3_msg.h"
#include "L3_timer.h"
#include "L3_LLinterface.h"
#include "protocol_parameters.h"
#include "mbed.h"

//FSM state -------------------------------------------------
#define L3STATE_IDLE                0
#define TX                          1


//state variables
static uint8_t main_state = L3STATE_IDLE; //protocol state
static uint8_t prev_state = main_state;

//SDU (input)
static uint8_t originalWord[1030];
static uint8_t wordLen=0;

static uint8_t sdu[1030];

//serial port interface
static Serial pc(USBTX, USBRX);

//match
static uint8_t matchArr[256] = {0}; //매칭대기열
static uint8_t matchShuffledArr[256] = {0}; 
static int matchCnt=0;
//static uint8_t mtchBackUpArr[256] = {0};
static uint8_t mtchCpl;

static int txIndex=0;

//application event handler : generating SDU from keyboard input
static void L3service_processInputWord(void)
{
    char c = pc.getc();
    if (!L3_event_checkEventFlag(L3_event_dataToSend))
    {
        if (c == '\n' || c == '\r')
        {
            originalWord[wordLen++] = '\0';
            L3_event_setEventFlag(L3_event_dataToSend);
            debug_if(DBGMSG_L3,"word is ready! ::: %s\n", originalWord);
        }
        else
        {
            originalWord[wordLen++] = c;
            if (wordLen >= L3_MAXDATASIZE-1)
            {
                originalWord[wordLen++] = '\0';
                L3_event_setEventFlag(L3_event_dataToSend);
                pc.printf("\n max reached! word forced to be ready :::: %s\n", originalWord);
            }
        }
    }
}


void L3_initFSM()
{
    //initialize service layer
    pc.attach(&L3service_processInputWord, Serial::RxIrq);
}

void L3_FSMrun(void)
{   
    if (prev_state != main_state)
    {
        debug_if(DBGMSG_L3, "[L3] State transition from %i to %i\n", prev_state, main_state);
        prev_state = main_state;
    }

    //FSM should be implemented here! ---->>>>
    switch (main_state)
    {
        case L3STATE_IDLE: //IDLE state description
            
            if (L3_event_checkEventFlag(L3_event_msgRcvd)) //msgRcvd is matchRcvd
            {
                //Retrieving data info.
                uint8_t* dataPtr = L3_LLI_getMsgPtr();
                uint8_t size = L3_LLI_getSize();
                uint8_t id = L3_LLI_getSrcId();

                debug("\n -------------------------------------------------\nRCVD Match Req by %i, (length:%i,sentence:%s)\n -------------------------------------------------\n", 
                            id, size, dataPtr);
                
                //매칭 대기열에 추가
                matchArr[matchCnt] = id;
                matchCnt++;
                printArr2(matchCnt);
                checkMatchCdtion();
                pc.printf("the number of matching user: %d\n",matchCnt);

                L3_event_clearEventFlag(L3_event_msgRcvd);
            }
           
            else if (L3_event_checkEventFlag(L3_event_matchStart)){
                mtchCpl = MATCHING(matchCnt);
                cleanMATCH(mtchCpl);
                
                L3_event_clearEventFlag(L3_event_matchStart);
                L3_event_setEventFlag(L3_event_matchingTx);
            }

            else if(L3_event_checkEventFlag(L3_event_matchingTx)){
                uint8_t user=0;
                uint8_t mate=0;
                
                if(txIndex<mtchCpl){
                    user = matchShuffledArr[txIndex];
                    if(txIndex%2==0){
                        mate = matchShuffledArr[txIndex+1];
                    }
                    else{
                        mate = matchShuffledArr[txIndex-1];
                    }

                    pc.printf("user:%d,mate:%d\n",user,mate);
                    L3_LLI_dataReqFunc(&mate, sizeof(uint8_t), user);

                    main_state = TX;        
                        
                    txIndex++;
                    break;

                }
                
                else{
                    L3_event_clearEventFlag(L3_event_matchingTx);
                    txIndex = 0;
                }
                
            }
            else{
                checkMatchCdtion();
            }
            break;
        case TX:
            if(L3_event_checkEventFlag(L3_event_dataSendCnf)){
                debug("\ndata sended!\n");
                main_state = L3STATE_IDLE;
                L3_event_clearEventFlag(L3_event_dataSendCnf);
            }
            break;
        default :
            break;
    }
}


int MATCHING(int size){
    //대기자수=size -> 배열 끝 index=size-1
    //except odd end user
    uint8_t temp_size = size;
    if(size%2==1){ 
        size--;
        matchCnt=1;
    }
    else{
        matchCnt=0;
    }
    if(size==2){
        for(int i=0;i<2;i++){
            matchShuffledArr[i] = matchArr[i];
        }
    }
    else{
    //shuffle
    srand(time(NULL));
    int ranNum;
    int temp;
    for(int i=0;i<size;i++){
        matchShuffledArr[i] = matchArr[i];
    }
    for(int i=0;i<=size-1;i++){
        ranNum = rand() % (size - i) + i;
        temp = matchShuffledArr[ranNum];
        matchShuffledArr[ranNum] = matchShuffledArr[i];
        matchShuffledArr[i] = temp;
    }
    }
    printArr(temp_size);
    pc.printf("the number of shuffled user: %d\n",size);
    return size;
}

void cleanMATCH(int num){
    int i=0;
    int end=num-1;
    if(matchCnt){
        i=1;
        end=num;
        matchArr[0] = matchArr[num];
    }
    while(i<=end){
        matchArr[i] = 0;
        i++;
    }
    printf("match Arr cleared!\n");
    printArr2(num);
}

void printArr(int len){
    pc.printf("shuffledArray: [");
    for(int i=0;i<len;i++){
        printf("%d ",matchShuffledArr[i]);
    }
    printf("]\n");
}
void printArr2(int len){
    pc.printf("matchArray: [");
    for(int i=0;i<len;i++){
        printf("%d ",matchArr[i]);
    }
    printf("]\n");
}

int checkMatchCdtion(){
    if (matchCnt>=2 && matchCnt<4 && L3_timer_getTimerStatus()==0){
        L3_timer_startTimer();
    }
    if (matchCnt>=4 || L3_event_checkEventFlag(L3_event_Timeout)){
        L3_event_setEventFlag(L3_event_matchStart);
        L3_event_clearEventFlag(L3_event_Timeout);
    }
    else {
        return 0;
    }
}